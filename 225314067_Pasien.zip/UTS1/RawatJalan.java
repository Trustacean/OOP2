package UTS1;

public class RawatJalan extends Pasien {
    private String jadwal;
    private String tindakan;

    RawatJalan(String nrm, String nama, String alamat, String dokter, int tahunlahir) {
        super(nrm, nama, alamat, dokter, tahunlahir);
    }

    public void setJadwal(String jadwal) {
        this.jadwal = jadwal;
    }

    public void setTindakan(String tindakan) {
        this.tindakan = tindakan;
    }
}

package UTS1;

public class Pasien {
    protected String nrm;
    protected String nama;
    protected String alamat;
    protected String dokter;
    protected int tahunlahir;

    Pasien(String nrm, String nama, String alamat, String dokter, int tahunlahir) {
        this.nrm = nrm;
        this.nama = nama;
        this.alamat = alamat;
        this.dokter = dokter;
        this.tahunlahir = tahunlahir;
    }

    public String getNrm() {
        return nrm;
    }

    public String getNama() {
        return nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getDokter() {
        return dokter;
    }

    public int getTahunlahir() {
        return tahunlahir;
    }


}

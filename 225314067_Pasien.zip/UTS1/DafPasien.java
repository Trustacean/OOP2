package UTS1;

import java.util.ArrayList;

public class DafPasien {
    private ArrayList<Pasien> list = new ArrayList<Pasien>();

    public DafPasien() {

    }

    public void add(Pasien p) {
        list.add(p);
    }

    public void remove(Pasien p) {
        list.remove(p);
    }

    public ArrayList<Pasien> getList() {
        return list;
    }

    public void display() {
        for (Pasien p : list) {
            System.out.println(p);
        }
    }
}

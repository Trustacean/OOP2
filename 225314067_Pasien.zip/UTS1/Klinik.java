package UTS1;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;

public class Klinik extends JFrame implements ActionListener {
    JMenuBar menuBar = new JMenuBar();
    JMenu edit = new JMenu("Edit");
    JMenuItem addPasienItem = new JMenuItem("Tambah Data Pasien");

    Klinik() {
        addPasienItem.addActionListener(this);
        edit.add(addPasienItem);
        menuBar.add(edit);

        setTitle("Klinik");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setJMenuBar(menuBar);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addPasienItem) {
            new EditDialog(this, "Edit Data Pasien");
            System.out.println("e");
        }
    }

    public static void main(String[] args) {
        new Klinik();
    }

}

class EditDialog extends JDialog {
    JFrame parent;
    JTextField nrmField = new JTextField(),
            namaField = new JTextField(),
            dokterField = new JTextField(),
            alamatField = new JTextField(),
            tahunField = new JTextField(),
            fieldVol1 = new JTextField(),
            fieldVol2 = new JTextField();
    JTextField[] fieldContainer = { nrmField, namaField, dokterField, alamatField, tahunField, fieldVol1, fieldVol2 };

    JLabel nrmLabel = new JLabel("Nrm : "),
            namaLabel = new JLabel("Nama : "),
            dokterLabel = new JLabel("Dokter : "),
            alamatLabel = new JLabel("Alamat : "),
            tahunLabel = new JLabel("Tahun : "),
            labelVol1 = new JLabel(),
            labelVol2 = new JLabel();
    JLabel[] labelContainer = { nrmLabel, namaLabel, dokterLabel, alamatLabel, tahunLabel,labelVol1, labelVol2 };
    String[] comboBoxItems = { "Rawat Inap", "Rawat Jalan" };
    JButton tambahButton = new JButton("Tambah");

    JTable pasienJTable = new JTable();
    JComboBox<String> box = new JComboBox<String>(comboBoxItems);
    int selectedIndex;

    DafPasien dafPasien = new DafPasien();

    EditDialog(JFrame parent, String title) {
        super(parent, title);
        this.parent = parent;
        setSize(900, 600);
        setResizable(false);
        setVisible(true);
        setLayout(null);

        for (int i = 0; i < 7; i++) {
            add(labelContainer[i]);
            labelContainer[i].setBounds(40, 180 + (i * 40), 100, 25);
            add(fieldContainer[i]);
            fieldContainer[i].setBounds(140, 180 + (i * 40), 200, 25);
        }

        add(box);
        box.setBounds(40, 120, 100, 25);
        add(tambahButton);
        tambahButton.setBounds(110, 450, 100, 25);

        box.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });

        tambahButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent a) {
                buttonAction();
            }
        });

        pasienStateChanged();
        showTable();

    }

    private boolean buttonAction() {
        try {
            isNumeric(tahunField.getText());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent, "Nope" + e.getMessage());
            return false;
        }

        try {
            isContainingNumber(namaField.getText());
            isContainingNumber(nrmField.getText());
            isContainingNumber(dokterField.getText());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent, "Nope" + e.getMessage());
            return false;
        }

        
        try {
            isYearValid(Integer.valueOf(tahunField.getText()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent, "Nope" + e.getMessage());
            return false;
        }
        Integer temp = Integer.valueOf(tahunField.getText());
        Pasien p = new Pasien(nrmField.getText(), namaField.getText(), alamatField.getText(),
                dokterField.getText(), temp);
        dafPasien.add(p);
        showTable();
        return true;
    }

    public boolean isContainingNumber(String text) throws Exception {
        for (int i = 0; i < text.length(); i++) {
            if (Character.isDigit(text.charAt(i))) {
                throw new Exception("contain number! ");
            }
        }
        return false;
    }

    public boolean isNumeric(String text) throws Exception {
        for (int i = 0; i < text.length(); i++) {
            if (!Character.isDigit(text.charAt(i))) {
                throw new Exception("is not numeric!");
            }
        }
        return true;
    }

    public boolean isYearValid(int year) throws Exception {
        if (year < 2000 || year > 2023) {
            throw new Exception();
        }
        return true;
    }

    private void showTable() {
        String[] columnNames = { "Nrm", "Nama", "Alamat", "Dokter", "Tahun Lahir" };

        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        pasienJTable = new JTable(model);
        pasienJTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        ListSelectionModel selectionModel = pasienJTable.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = pasienJTable.getSelectedRow();
                    for (int i = 0; i < 5; i++) {
                        fieldContainer[i].setText((String) pasienJTable.getValueAt(selectedRow, i));
                    }

                }
            }
        });

        for (int i = 0; i < dafPasien.getList().size(); i++) {
            String[] temp = new String[5];
            temp[0] = (dafPasien.getList().get(i).getNrm());
            temp[1] = (dafPasien.getList().get(i).getNama());
            temp[2] = (dafPasien.getList().get(i).getAlamat());
            temp[3] = (dafPasien.getList().get(i).getDokter());
            temp[4] = Integer.toString((dafPasien.getList().get(i).getTahunlahir()));
            model.addRow(temp);
        }

        JScrollPane scrollPane = new JScrollPane(pasienJTable);
        scrollPane.setBounds(370, 20, 500, 500);

        add(scrollPane);
    }

    void pasienStateChanged() {
        selectedIndex = box.getSelectedIndex();
        
    }
}

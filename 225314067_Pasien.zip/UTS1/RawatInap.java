package UTS1;

import java.time.LocalDate;

public class RawatInap extends Pasien {
    private String kamar;
    private LocalDate tgmasuk;

    RawatInap(String nrm, String nama, String alamat, String dokter, int tahunlahir) {
        super(nrm, nama, alamat, dokter, tahunlahir);
    }

    public void setKamar(String kamar) {
        this.kamar = kamar;
    }

    public void setTgmasuk(LocalDate tgmasuk) {
        this.tgmasuk = tgmasuk;
    }

    
}
